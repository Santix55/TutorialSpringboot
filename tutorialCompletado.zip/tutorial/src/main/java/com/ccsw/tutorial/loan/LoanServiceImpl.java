package com.ccsw.tutorial.loan;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.ccsw.tutorial.client.ClientService;
import com.ccsw.tutorial.common.criteria.SearchCriteria;
import com.ccsw.tutorial.game.GameService;
import com.ccsw.tutorial.loan.model.Loan;
import com.ccsw.tutorial.loan.model.LoanDto;
import com.ccsw.tutorial.loan.model.LoanSearchDto;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class LoanServiceImpl implements LoanService {
    @Autowired
    LoanRepository loanRepository;

    @Autowired
    GameService gameService;

    @Autowired
    ClientService clientService;

    @Override
    public Page<Loan> find(LoanSearchDto dto) {
        var gameSpec = new LoanSpecification(new SearchCriteria("game.id", ":", dto.getIdGame()));
        var clientSpec = new LoanSpecification(new SearchCriteria("client.id", ":", dto.getIdClient()));
        var startSpec = new LoanSpecification(new SearchCriteria("startDate", "<=", dto.getDate()));
        var endSpec = new LoanSpecification(new SearchCriteria("endDate", ">=", dto.getDate()));

        var spec = Specification.where(gameSpec).and(clientSpec).and(startSpec).and(endSpec);
        return loanRepository.findAll(spec, dto.getPageable().getPageable());
    }

    @Override
    public void delete(Long id) throws Exception {
        if (this.loanRepository.findById(id).orElse(null) == null) {
            throw new Exception("Not Exist");
        }
        this.loanRepository.deleteById(id);
    }

    @Override
    public void save(LoanDto dto) throws Exception {
        var startDate = dto.getStartDate();
        var endDate = dto.getEndDate();
        var client = dto.getClient();
        var game = dto.getGame();

        System.err.println("==========================================");
        System.err.println("-- VARIABLES DEL DTO --");
        System.err.println("startDate = " + startDate.toString());
        System.err.println("endDate = " + endDate.toString());
        System.err.println("");

        long daysDiff = ChronoUnit.DAYS.between(startDate, endDate);

        // COMPROBAR QUE EL PERIODO DE PRÉSTAMO ES DE 14 DÍAS
        if (daysDiff > 14 || daysDiff < 0)
            throw new Exception("The period of the loan has to be of 14 maximum and not negative");

        // recorrer día a día desde la fecha incio hasta la final
        for (LocalDate day = LocalDate.of(startDate.getYear(), startDate.getMonth(), startDate.getDayOfMonth()); day
                .compareTo(endDate) <= 0; day = day.plusDays(1)) {

            var clientSpec = new LoanSpecification(new SearchCriteria("client.id", ":", client.getId()));
            var gameSpec = new LoanSpecification(new SearchCriteria("game.id", ":", game.getId()));
            var startSpec = new LoanSpecification(new SearchCriteria("startDate", "<=", day));
            var endSpec = new LoanSpecification(new SearchCriteria("endDate", ">=", day));

            System.err.println("-- DÍA = " + day.toString() + " --");

            // COMPROBAR QUE EL CLIENTE NO TENGA MÁS DE UN JUEGO EL MISMO DÍA
            var spec1 = Specification.where(clientSpec).and(startSpec).and(endSpec);
            long ngames = loanRepository.count(spec1);
            System.err.println("ngames = " + ngames);
            if (ngames >= 2) {
                throw new Exception("A client can't have more than 2 games the same day: " + day.toString());
            }

            // COMPROBAR QUE EL JUEGO NO APARECE PRESTADO OTRA VEZ A CUALQUIER PERSONA
            var spec2 = Specification.where(gameSpec).and(startSpec).and(endSpec);
            if (loanRepository.exists(spec2)) {
                System.err.println("exist = true");
                throw new Exception("The game can't appear in two times in the same day : " + day.toString());
            }
            System.err.println("exist = false");

            System.err.println();
        }

        Loan loan = new Loan();
        loan.setGame(gameService.get(dto.getGame().getId()));
        loan.setClient(clientService.get(dto.getClient().getId()));
        loan.setStartDate(dto.getStartDate());
        loan.setEndDate(dto.getEndDate());
        this.loanRepository.save(loan);
    }

}
